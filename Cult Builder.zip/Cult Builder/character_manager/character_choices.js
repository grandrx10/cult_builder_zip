export class Character_Choices {
    constructor(){
        
    }
}