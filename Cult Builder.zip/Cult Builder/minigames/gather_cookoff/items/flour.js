import { Item } from "./item.js"

export class Flour extends Item {
    constructor(x, y, speed){
        super("Flour", x, y, 80, 100, speed, loadImage("assets/images/cooking_images/flour.png"))
    }
}