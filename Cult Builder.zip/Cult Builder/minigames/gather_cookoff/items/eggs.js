import { Item } from "./item.js"

export class Eggs extends Item {
    constructor(x, y, speed){
        super("Eggs", x, y, 60, 80, speed, loadImage("assets/images/cooking_images/eggs.png"))
    }
}