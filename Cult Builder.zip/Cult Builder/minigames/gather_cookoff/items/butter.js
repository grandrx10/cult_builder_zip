import { Item } from "./item.js"

export class Butter extends Item {
    constructor(x, y, speed){
        super("Butter", x, y, 100, 80, speed, loadImage("assets/images/cooking_images/butter.png"))
    }
}