import { Kithan_Choices } from "./kithan_choices.js"
import { Character } from "../../character_manager/character.js"
import { Dialogue } from "../../dialogue_classes/dialogue.js"

export class Kithan extends Character{ // <- change Character_Name to your character's name! No spaces or special characters
    constructor(){
        super("Kithan") // <- change to be your own character name. You may use spaces and special characters here.
        this.set_possible_dialogue()
        this.set_colors()
        this.load_images()
        this.load_audio()

        this.character_choices = new Kithan_Choices() // <- replace Char_Name with your character's name, no spaces or special characters.
    }

    /** READ ME: each character is on a dialogue_path, which determines what they are saying.
     * 
     * DIALOGUE:
     * 
     * The dialogue is in chronological order. Without any parameters, one will proceed to the next.
     * Each dialogue_path must be encompassed by square brackets: [ "Example text here!" , "Second text here!" ]
     * 
     * If you wish to use a stat from cult_stats, you must refer to it in brackets within the text.
     * [ "Your name is [name]" ] <- this will replace with [name] with the corresponding stat in cult_stats.
     * 
     * To set the speaker of your dialogue, add {Speaker:char_name} to the front of your text.
     * {Speaker:} will set the speaker to no one. This can be used for narration.
     *  
     * To move from one dialogue path to the other, just add (Go) to the start of your text.
     * Example: [ "(Go)example_2_dialogue_path" ]  <- this makes the character move to dialogue path example_2_dialogue_path
     * 
     * To make a choice, add (Choice) then the name of the choice. Please consult char_name_choices.js and make sure your choice is there
     * Example: [ "(Choice)example_choice" ] 
     *
     * To end a dialogue, add (End), then the begginning of the next dialogue path for that character.
     * Example: [ "(End)last_example_dialogue_path" ]
     * 
     * IMAGES:
     * 
     * To display images, make sure to load images at the bottom of this class.
     * {name_of_image:display_location} <- this will display the desired image at the desired location
     * {Edlith:middle} <- example display
     * Possible display locations are: middle, left, right
     * Note: No spaces are allowed in this statement. Mind capitals.
     * 
     * VARIABLES:
     * If you want to change cult_stats variables, add <> at the front of your dialogue sentence.
     * If your variable is not already in cult_stats, it will create that variable. You may add any positive or negative number.
     * You may also change multiple cult_stats. (You may use add or set)
     * [ "<name_of_variable:add:value_here>Example text here!" ] or [ "<var1:add:value_here><var2:set:value_here>Example text here!" ]
     * 
     * If you want dialogue to ONLY appear when certain stats are fulfilled, then do this:
     * [ "<name_of_variable:more/less:value_here>Example text here!" ]
     * Note: choose either more or less. They are inclusive.
     */
    set_possible_dialogue(){
        this.dialogue_path = new Dialogue("intro") // make sure this is the dialogue path you want to start on <encounters:more:3>
        this.possible_dialogue = { // <encounters:more:3>
            "intro": ["{Speaker:???}{Kithan:middle}Heya there! Yeah, you over there, I'm talking to you!",
            "{Speaker:Kithan}My name is Kithan, it's nice to meet you. Say, you don't happen to have a good spot for hiding a body, do you?",
            "(Choice)hide_body"],

            "asking_why_body": ["Oh, why? No reason why, I was just asking! I have this bag I want to store for a while. I'll pay you if you take it.",
            "(Choice)hide_body_2"],

            "no_body": [
                "<kithan_relations:add:-5>No? Ugh, okay, lame boy. Your loss!",
                "(Go)introduce_kithan"
            ],

            "under_bed_body": ["Thanks. Do you mind stashing this down there for a while?",
            "{Speaker:}He hands you a suspicious looking black bag.",
            "{Speaker:Kithan}Here's some coins for your troubles.",
            "<Gold:add:+15><kithan_relations:add:+5>(Go)introduce_kithan"],

            "already_hiding": [
                "Oh, that's quite unfortunate. Do let me know when you have a vacant spot open!",
                "(Go)introduce_kithan"
            ],

            "introduce_kithan": [
                "Oh, where are my manners? I have to introduce myself. I am Kithan, Kithan Greenmoth. " + 
                "I am a blood enthusiast, lover of flesh, hater of the sun.",
                "(Choice)vampire_discovery"
            ],

            "vampire_stutter": [
                "That's awfully rude of you! The v-word is a derogatory term. I much prefer to be called a scum sucking leech.",
                "But more or less, I am what you called me, and I am quite thirsty. You wouldn't happen to have any blood on hand, would you?",
                "{Speaker:}He sniffs the air.",
                "{Speaker:Kithan}Oh, you definitely do. And it smells wonderful.",
                "(Go)challenge_blood"
            ],

            "favourite_blood_type": [
                "My favourite blood is type O, thank you for asking!",
                "{Speaker:}He sniffs the air.",
                "{Speaker:Kithan}Ah, you smell just absolutely delightful! Is your blood GMO free?",
                "Oh yeah, definitely. And free range too.",
                "(Go)challenge_blood"
            ],

            "drink_blood": [
                "Oh, really? Don't mind if I do!",
                "{Speaker:}He bites into your neck. You feel the blood flowing out of your body.",
                "You feel weaker.",
                "{Speaker:Kithan}<strength:add:-10>Thank you, that was some fine blood you got there. I want more, of course, but it feels wrong to take it for free.",
                "Would you perhaps like to have a duel for it?",
                "If you win, I will reward you handsomely. If I win, you will have to let me drink some of that gourmet red sauce that flows through you.",
                "Sound fair?",
                "(Choice)blood_suck_ask"
            ],

            "challenge_blood": [
                "I'll be direct with you. I want to suck your blood. I won't take it for free though, that'd just be communism.",
                "No, instead, I propose that we duel for it!",
                "If you win, I will reward you handsomely. If I win, you will have to let me drink some of that gourmet red sauce that flows through you.",
                "Sound fair?",
                "(Choice)blood_suck_ask"
            ],

            "duel_begin": [
                "I knew you would accept! Very well, prepare yourself for a duel!"
            ],

            "duel_reject": [
                "Hell no? Yeah, I don't like hell either.",
                "What about the duel, though?",
                "(Choice)blood_suck_ask"
            ],



            // "(Go)example_dialogue_path"]
            "<no_talk:is:1>end": [""],
        }
    }

    set_possible_response(){
        this.possible_response_dialogue = []
    }

    load_images(){
        this.images["Kithan"] = loadImage('assets/images/kithan.png'); // <- upload your own image and use it here!

        // this.images["Your Character Here"] = loadImage('assets/images/char_name.png'); <- example second image

    }

    load_audio(){
        this.audio = loadSound('assets/audio/kithan_soundtrack.mp3') // <- upload your own soundtrack and use it here!

        // not flyers but maybe something else
        // atomic man
    }
}