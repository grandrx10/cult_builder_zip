import { Character_Choices } from "../../character_manager/character_choices.js";

export class Kithan_Choices extends Character_Choices{ // <- Change Char_Name to your character's name
    constructor(){
        super()
    }

    /**
     * These choices may be initiated by the char_name function.
     * hash will contain all choices for that choice situation.
     * 
     * You can make only certain options available by doing the same thing like in normal dialogue
     * [ "Example text here!", [ [ "name_of_variable", "more/less", number_here ] ] ]
     */
    initiate_choice(choice, possible_dialogue, text_box, choice_display, cult_stats){
        var hash;
        switch(choice){
            case "hide_body":
                hash = {
                    "Why are you asking?" : "asking_why_body",
                    "Yeah sure, you can put it under my bed" : "under_bed_body",
                    "No, I'm already hiding one": "already_hiding",
                    "Absolutely not!": "no_body"
                }
                break;
            case "hide_body_2":
                hash = {
                    "Absolutely not!" : "no_body",
                    "Yeah sure, you can put it under my bed" : "under_bed_body"
                }
                break;
            case "vampire_discovery":
                hash = {
                    "Y-y-y-you're a vampire!" : "vampire_stutter",
                    "What's your favourite blood type?" : "favourite_blood_type",
                    "I would let you drink my blood": "drink_blood"
                }
                break;
            case "blood_suck_ask":
                hash = {
                    "You're on!": "duel_begin",
                    "Hell no!": "duel_reject"
                }
                break;
        }
        choice_display.set_choices(hash, cult_stats)
    }
}